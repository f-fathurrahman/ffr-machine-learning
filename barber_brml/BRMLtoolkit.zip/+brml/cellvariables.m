function v=cellvariables(c)
if ~isempty(c)
    v=c.variables;
else
    v=[];
end