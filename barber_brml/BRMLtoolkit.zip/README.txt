Please run setup.m 

help Contents

displays list of the files.

There are bugs in the Matlab JIT compiler that may prevent the code
working correctly. Setup.m will turn off the JIT compiler if it
detects a bug.

Setup also adds Taylan Cemgils' graphlayout package and Mark Schmidt's minFunc package (http://www.di.ens.fr/~mschmidt/Software/minFunc.html) to the path.

See LICENSE.txt for the license.


I'd like to thank the following people for help, bug fixes and suggestions to the code:

Taylan Cemgil
Zakria Hussain
Chris Bracegirdle
Tom Minka
Sebastien Bretieres
Tomasz Kacprzak
Guangyan Song
Timothy Scully
Ed Wright
Nikos Vlassis


David Barber
Department of Computer Science
University Collge London