Please run setup.m 

help Contents

displays list of the files.

There are bugs in the Matlab JIT compiler that may prevent the code
working correctly. Setup.m will turn off the JIT compiler if it
detects a bug.

Setup also adds the graphlayout package from A.T. Cemgil to the path.

See LICENSE.txt for the license.

David Barber davidobarber@gmail.com
Department of Computer Science
University Collge London
November 2008