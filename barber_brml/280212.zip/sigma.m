function s=sigma(x)
%SIGMA 1./(1+exp(-x))
% s=sigma(x) = 1./(1+exp(-x))
s=1./(1+exp(-x));